"""
Haven Language Interactive REPL (Read-Eval-Print Loop)
With native syntax evaluation, live ODCS ledger inspection, and command helpers.
"""

import sys
import os
import traceback
try:
    if sys.platform != "win32":
        import readline
except ImportError:
    pass
from .colors import green, yellow, cyan, bold, dim, red, magenta
import haven
import odcs


BANNER = f"""
{bold(cyan('╔═══════════════════════════════════════════════════════════════╗'))}
{bold(cyan('║                    HAVEN LANGUAGE v1.0.0                      ║'))}
{bold(cyan('║     Open Digital Continuity Standard (ODCS Edition)           ║'))}
{bold(cyan('║        Specification & Architecture by Anirudha Puthraya      ║'))}
{bold(cyan('╚═══════════════════════════════════════════════════════════════╝'))}
Type {bold(':help')} for special REPL commands, or {bold(':quit')} to exit.
"""

HELP_TEXT = f"""
{bold(cyan('Haven REPL Interactive Commands:'))}
  {green(':help')}             Display this help guide
  {green(':ledger')}           View current blocks in the default continuity ledger
  {green(':audit')}            Cryptographically verify the ledger chain
  {green(':clear')}            Clear the terminal screen
  {green(':history')}          View session execution history
  {green(':quit')} / {green(':exit')}     Exit the REPL session

{bold(cyan('Native Syntax Examples:'))}
  {yellow('set x to 42')}
  {yellow('repeat 3 times: print("Hello from Haven!")')}
  {yellow('unless x == 0: print("Non-zero:", x)')}
  {yellow('"test" |> len')}
  {yellow('checkpoint {{"msg": "data"}} as "my_data"')}
"""


def start_repl() -> None:
    """Starts the Haven interactive REPL."""
    print(BANNER)

    # Initialize execution environment
    repl_globals = {
        "__name__": "__main__",
        "__doc__": "Haven Interactive REPL Session",
        "haven": haven,
        "odcs": odcs,
    }

    # Preload all haven & odcs symbols into REPL namespace
    for mod in (haven, odcs):
        for attr in getattr(mod, "__all__", []):
            if hasattr(mod, attr):
                repl_globals[attr] = getattr(mod, attr)

    history = []
    buffer = []

    prompt_primary = f"{cyan('haven')} > "
    prompt_secondary = f"{dim('....')} > "

    while True:
        try:
            prompt = prompt_secondary if buffer else prompt_primary
            line = input(prompt)
        except (EOFError, KeyboardInterrupt):
            print("\nExiting Haven REPL.")
            break

        stripped = line.strip()

        # Handle REPL meta-commands
        if not buffer and stripped.startswith(":"):
            cmd = stripped.lower()
            if cmd in (":quit", ":exit", ":q"):
                print("Goodbye!")
                break
            elif cmd == ":help":
                print(HELP_TEXT)
                continue
            elif cmd == ":ledger":
                _print_ledger(repl_globals)
                continue
            elif cmd == ":audit":
                _audit_ledger(repl_globals)
                continue
            elif cmd == ":clear":
                os.system("cls" if sys.platform == "win32" else "clear")
                continue
            elif cmd == ":history":
                for idx, h in enumerate(history, start=1):
                    print(f"  {idx:03d}: {h}")
                continue
            else:
                print(f"{red('Unknown REPL command:')} {cmd}. Type :help for commands.")
                continue

        buffer.append(line)
        code_block = "\n".join(buffer)

        # Check if more lines are needed (e.g. block ending in :)
        if line.endswith(":") or (line and line[0] in (" ", "\t")):
            continue

        history.append(code_block)
        buffer.clear()

        # Attempt to compile and evaluate
        try:
            # First try evaluating as an expression to auto-print results
            compiled = compile(code_block, "<haven-repl>", "eval")
            result = eval(compiled, repl_globals)
            if result is not None:
                print(repr(result))
        except SyntaxError:
            # If not an expression, try compiling as statement block
            try:
                compiled = compile(code_block, "<haven-repl>", "exec")
                exec(compiled, repl_globals)
            except Exception as e:
                _handle_repl_error(e)
        except Exception as e:
            _handle_repl_error(e)


def _handle_repl_error(e: Exception) -> None:
    from haven import ContinuityImmutabilityError
    from odcs import ContinuityIntegrityError

    if isinstance(e, (ContinuityImmutabilityError, ContinuityIntegrityError)):
        print(f"{bold(yellow('[ODCS SECURITY REJECTION]'))} {bold(str(e))}")
    else:
        exc_type, exc_val, exc_tb = sys.exc_info()
        traceback.print_exception(exc_type, exc_val, exc_tb)


def _print_ledger(repl_globals: dict) -> None:
    from odcs import get_default_ledger
    ledger = get_default_ledger()
    entries = ledger.entries

    print(f"\n{bold(cyan('Default Continuity Ledger:'))} {ledger.name}")
    print(f"Total Blocks: {len(entries)} | Head Hash: {ledger.head_hash[:20]}...\n")

    for e in entries:
        alias_str = f" [alias: {e.alias}]" if e.alias else ""
        print(f"  #{e.index:02d} {dim(e.timestamp[:19])} | Hash: {e.entry_hash[:16]}... | Prev: {e.prev_hash[:16]}...{alias_str}")
    print()


def _audit_ledger(repl_globals: dict) -> None:
    from odcs import get_default_ledger
    ledger = get_default_ledger()
    valid = ledger.verify_chain()

    if valid:
        print(f"\n{bold(green('✔ Default Ledger Chain AUDIT PASSED:'))} {len(ledger.entries)} block(s) cryptographically verified.\n")
    else:
        print(f"\n{bold(red('✖ Default Ledger Chain AUDIT FAILED!'))}\n")
