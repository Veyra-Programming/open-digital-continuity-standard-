"""
Haven Script Runner
Executes Haven (.hvn, .haven) and Python (.py) programs with environment configuration,
argument forwarding, and high-precision timing.
"""

import sys
import os
import time
import traceback
from .colors import green, red, yellow, cyan, bold, dim


def run_script(file_path: str, script_args: list, measure_time: bool = False, verbose: bool = False) -> int:
    """Executes a Haven script file and returns exit code."""
    if not os.path.exists(file_path):
        # Try checking with extensions
        found = None
        for ext in (".hvn", ".haven", ".py"):
            candidate = file_path + ext
            if os.path.exists(candidate):
                found = candidate
                break
        if found:
            file_path = found
        else:
            print(f"{bold(red('Error:'))} File not found: '{file_path}'", file=sys.stderr)
            return 1

    old_argv = list(sys.argv)
    old_sys_path = list(sys.path)
    old_modules = set(sys.modules.keys())
    old_main = sys.modules.get("__main__")

    file_path = os.path.abspath(file_path)
    script_dir = os.path.dirname(file_path)

    # Ensure script's directory and package root are in sys.path
    for p in (script_dir, os.path.dirname(script_dir), os.getcwd()):
        if p and p not in sys.path:
            sys.path.insert(0, p)

    # Prepare sys.argv for the target script
    sys.argv = [file_path] + script_args

    if verbose:
        print(dim(f"[*] Executing Haven script: {file_path}"))
        print(dim(f"[*] Arguments: {script_args}"))

    start_time = time.perf_counter()
    exit_code = 0

    import types
    main_mod = types.ModuleType("__main__")
    main_mod.__file__ = file_path
    main_globals = main_mod.__dict__
    sys.modules["__main__"] = main_mod

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            code_str = f.read()

        compiled = compile(code_str, file_path, "exec")
        exec(compiled, main_globals)

    except SystemExit as se:
        exit_code = se.code if isinstance(se.code, int) else (0 if se.code is None else 1)
    except Exception as e:
        exit_code = 1
        exc_type, exc_val, exc_tb = sys.exc_info()
        print(f"\n{bold(red('✖ Unhandled Exception during Haven execution:'))}", file=sys.stderr)
        
        # Check if it's an ODCS-specific exception
        from haven import ContinuityImmutabilityError
        from odcs import ContinuityIntegrityError
        
        if isinstance(e, (ContinuityImmutabilityError, ContinuityIntegrityError)):
            print(f"{bold(yellow('[ODCS SECURITY VIOLATION]'))} {bold(str(e))}", file=sys.stderr)
            print(dim("The Open Digital Continuity Standard prevented an illegal state or proof mutation."), file=sys.stderr)
        else:
            traceback.print_exception(exc_type, exc_val, exc_tb)
    finally:
        sys.argv = old_argv
        sys.path = old_sys_path
        if old_main is not None:
            sys.modules["__main__"] = old_main
        # Remove newly imported modules to avoid cross-project caching collisions
        for m in list(sys.modules.keys()):
            if m not in old_modules:
                sys.modules.pop(m, None)

    duration_ms = (time.perf_counter() - start_time) * 1000.0
    if measure_time:
        print(dim(f"\n[Execution completed in {duration_ms:.2f} ms with exit code {exit_code}]"))

    return exit_code
