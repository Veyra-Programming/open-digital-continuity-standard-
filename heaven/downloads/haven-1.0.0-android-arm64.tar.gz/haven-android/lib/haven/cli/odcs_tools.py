"""
Haven ODCS CLI Tools
Cryptographic Ledger Auditing, Replay, Inspection, and Verification under ODCS-1.0.0.
Specification & Architecture by Anirudha Puthraya.
"""

import sys
import os
import json
from datetime import datetime
from .colors import green, red, yellow, cyan, bold, dim, blue, magenta


def handle_odcs_command(args: list) -> int:
    """Dispatches ODCS subcommands."""
    if not args or args[0] in ("-h", "--help", "help"):
        _print_odcs_help()
        return 0

    subcmd = args[0].lower()
    subargs = args[1:]

    if subcmd == "audit":
        return _cmd_audit(subargs)
    elif subcmd == "replay":
        return _cmd_replay(subargs)
    elif subcmd == "inspect":
        return _cmd_inspect(subargs)
    elif subcmd == "verify":
        return _cmd_verify(subargs)
    elif subcmd in ("new-algorithm", "new-algo"):
        from .scaffolder import scaffold_project
        if not subargs:
            print(f"{bold(red('Error:'))} Package name required: haven odcs new-algorithm <name>", file=sys.stderr)
            return 1
        return scaffold_project(subargs[0], template="odcs-algorithm")
    elif subcmd in ("new-app", "create-app"):
        from .scaffolder import scaffold_project
        if not subargs:
            print(f"{bold(red('Error:'))} Application name required: haven odcs new-app <name>", file=sys.stderr)
            return 1
        return scaffold_project(subargs[0], template="odcs-app")
    elif subcmd == "info":
        return _cmd_info()
    else:
        print(f"{bold(red('Unknown ODCS command:'))} {subcmd}", file=sys.stderr)
        _print_odcs_help()
        return 1


def _print_odcs_help() -> None:
    print(f"""
{bold(cyan('Open Digital Continuity Standard (ODCS) CLI Toolkit'))}
{dim('Standard Specification & Architecture by Anirudha Puthraya')}

{bold('Usage:')}
  haven odcs <subcommand> [options]

{bold('Commands:')}
  {green('audit')} <journal_file>       Audit unbroken cryptographic chain and Merkle proofs
  {green('replay')} <journal_file>      Replay journal from genesis to verify deterministic recovery
  {green('inspect')} <journal_file>     Inspect blocks and envelope payloads in a journal
  {green('verify')} <asset> <proof>     Cryptographically verify an asset or hash proof
  {green('new-algorithm')} <name>       Scaffold a new ODCS Continuity Algorithm package
  {green('new-app')} <name>             Scaffold a new ODCS-based Application System
  {green('info')}                       Display ODCS specification standards and architecture
""")


def _cmd_info() -> int:
    import odcs
    print(f"""
{bold(cyan('========================================================='))}
{bold(cyan('  Open Digital Continuity Standard (ODCS) Specification  '))}
{bold(cyan('========================================================='))}
  {bold('Standard Level:')}          ODCS-1.0.0
  {bold('Specification Author:')}    Anirudha Puthraya
  {bold('Engine Implementation:')}   Haven Language Native ODCS Core v{odcs.__version__}
  {bold('Canonicalization:')}        RFC 8785 JSON Determinism
  {bold('Hash Digest:')}             SHA-256 (32-byte hexadecimal)
  {bold('Integrity Engine:')}        Field-level Binary Merkle Trees
  {bold('Guarantees:')}
    ✓ Durable Record Immutability Enforcement
    ✓ Tamper-Evident Append-Only Cryptographic Ledgers
    ✓ Zero-Loss Disaster Recovery & Journal Replay
    ✓ Verifiable Continuity Algorithms & Multi-Actor Consensus
    ✓ Cross-Generational Forward Schema Evolution
{bold(cyan('========================================================='))}
""")
    return 0


def _cmd_audit(args: list) -> int:
    if not args:
        print(f"{bold(red('Error:'))} Journal file path required: haven odcs audit <journal_file>", file=sys.stderr)
        return 1

    journal_path = args[0]
    if not os.path.exists(journal_path):
        print(f"{bold(red('Error:'))} Journal file '{journal_path}' does not exist.", file=sys.stderr)
        return 1

    from odcs import ContinuityLedger, ContinuityIntegrityError

    print(f"[*] Starting ODCS Cryptographic Chain Audit on: {bold(journal_path)}")
    try:
        with open(journal_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        ledger = ContinuityLedger.replay_journal(journal_path)
        valid = ledger.verify_chain()

        entries = ledger.entries
        print(f"\n{bold('Ledger Audit Summary:')}")
        print(f"  Standard:     {cyan(data.get('standard', 'ODCS-1.0.0'))}")
        print(f"  Author:       {cyan(data.get('author', 'Anirudha Puthraya'))}")
        print(f"  Ledger Name:  {bold(ledger.name)}")
        print(f"  Total Blocks: {len(entries)}")
        print(f"  Head Hash:    {ledger.head_hash}")

        print(f"\n{bold('Block Verification Breakdown:')}")
        for i, entry in enumerate(entries):
            env = entry.envelope
            status = green("✓ VALID") if entry.verify() else red("✖ TAMPERED")
            print(f"  Block #{entry.index:03d} [{status}] Hash: {entry.entry_hash[:20]}... Type: {env.asset_type}")

        if valid:
            print(f"\n{bold(green('✔ AUDIT PASSED:'))} Unbroken cryptographic lineage verified from Genesis to Head.")
            return 0
        else:
            print(f"\n{bold(red('✖ AUDIT FAILED:'))} Cryptographic hash chain mismatch or envelope tampering detected!", file=sys.stderr)
            return 1

    except Exception as e:
        print(f"{bold(red('Audit Failure:'))} {e}", file=sys.stderr)
        return 1


def _cmd_replay(args: list) -> int:
    if not args:
        print(f"{bold(red('Error:'))} Journal file path required: haven odcs replay <journal_file>", file=sys.stderr)
        return 1

    journal_path = args[0]
    if not os.path.exists(journal_path):
        print(f"{bold(red('Error:'))} Journal file not found: {journal_path}", file=sys.stderr)
        return 1

    from odcs import ContinuityLedger
    print(f"[*] Replaying ODCS Ledger Journal: {bold(journal_path)}")
    try:
        ledger = ContinuityLedger.replay_journal(journal_path)
        print(f"{bold(green('✔ Replay Successful:'))} Reconstructed {len(ledger.entries)} blocks.")
        print(f"    Restored Head Hash: {cyan(ledger.head_hash)}")
        return 0
    except Exception as e:
        print(f"{bold(red('Replay Failed:'))} {e}", file=sys.stderr)
        return 1


def _cmd_inspect(args: list) -> int:
    if not args:
        print(f"{bold(red('Error:'))} Journal file path required: haven odcs inspect <journal_file>", file=sys.stderr)
        return 1

    journal_path = args[0]
    if not os.path.exists(journal_path):
        print(f"{bold(red('Error:'))} File not found: {journal_path}", file=sys.stderr)
        return 1

    try:
        with open(journal_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        print(f"{bold(cyan('ODCS Journal Inspection:'))} {journal_path}")
        print(f"Ledger Name:   {data.get('ledger_name')}")
        print(f"Standard:      {data.get('standard')}")
        print(f"Specification: {data.get('author')}")
        print(f"Total Entries: {data.get('total_entries')}")
        print(f"Head Hash:     {data.get('head_hash')}")

        entries = data.get("entries", [])
        print(f"\n{bold('Recent Blocks:')}")
        for e in entries[-5:]:
            env = e.get("envelope", {})
            print(f"  #{e.get('index')} | Prev: {e.get('prev_hash')[:16]}... | Hash: {e.get('entry_hash')[:16]}... | Type: {env.get('asset_type')}")

        return 0
    except Exception as e:
        print(f"{bold(red('Inspection Error:'))} {e}", file=sys.stderr)
        return 1


def _cmd_verify(args: list) -> int:
    if len(args) < 2:
        print(f"{bold(red('Error:'))} Both asset/file and expected proof required: haven odcs verify <asset_or_file> <proof>", file=sys.stderr)
        return 1

    target = args[0]
    proof = args[1]

    from odcs import verify_continuity, compute_sha256, canonical_json

    if os.path.exists(target):
        with open(target, "r", encoding="utf-8") as f:
            content = f.read()
        try:
            target_data = json.loads(content)
        except Exception:
            target_data = content
    else:
        target_data = target

    try:
        verify_continuity(target_data, proof)
        print(f"{bold(green('✔ Cryptographic Proof Verified Successfully!'))}")
        return 0
    except Exception as e:
        print(f"{bold(red('✖ Proof Verification Failed:'))} {e}", file=sys.stderr)
        return 1

