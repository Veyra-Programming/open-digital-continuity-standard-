"""
Haven System Information & Diagnostic Reporter
"""

import sys
import os
import platform
from .colors import green, yellow, cyan, bold, dim, blue, magenta


def print_info() -> int:
    import haven
    import odcs

    print(f"""
{bold(cyan('========================================================='))}
{bold(cyan('           Haven Programming Language Environment        '))}
{bold(cyan('========================================================='))}
  {bold('Haven Version:')}        {green(haven.__version__)}
  {bold('ODCS Standard:')}        {cyan(haven.__standard__)} (ODCS-1.0.0)
  {bold('Specification Author:')} {bold('Anirudha Puthraya')}
  {bold('CPython Substrate:')}    {platform.python_version()} [{platform.python_implementation()}]
  {bold('Platform OS:')}          {platform.system()} {platform.release()} ({platform.machine()})
  {bold('Compiler:')}             {platform.python_compiler()}
  {bold('Executable Path:')}      {sys.executable}
  {bold('Interpreter Prefix:')}   {sys.prefix}

{bold('Language Capabilities & Syntax Engine:')}
  ✓ Natural English Syntax   : `set x to val`, `let x be val`, `to func():`
  ✓ Iteration Control        : `repeat N times:`
  ✓ Conditional Guard        : `unless condition:`
  ✓ Pipelining Engine        : `val |> func(_)`, `val into ledger`
  ✓ ODCS Durable Records     : `durable record Name:`
  ✓ Cryptographic Continuity : `checkpoint record as alias into ledger`
  ✓ Proof Verification       : `verify asset with expected_proof`
  ✓ Consensus & Algorithms   : `ContinuityAlgorithm`, `StateContinuityAlgorithm`, `ODCSApp`

{bold('Standard Module Search Paths:')}""")
    for p in sys.path[:5]:
        print(f"  • {dim(p)}")
    if len(sys.path) > 5:
        print(f"  • {dim(f'... ({len(sys.path) - 5} more directories)')}")

    print(f"{bold(cyan('========================================================='))}\n")
    return 0
