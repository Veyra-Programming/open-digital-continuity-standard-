#!/data/data/com.termux/files/usr/bin/sh
echo "Installing Haven Language into Termux environment..."
pkg install -y python
PREFIX="/data/data/com.termux/files/usr"
mkdir -p "$PREFIX/lib/haven" "$PREFIX/bin"
cp -r lib/* "$PREFIX/lib/haven/"
cp bin/haven "$PREFIX/bin/haven"
chmod +x "$PREFIX/bin/haven"
echo "Haven installed successfully! Type 'haven --help' to test."
