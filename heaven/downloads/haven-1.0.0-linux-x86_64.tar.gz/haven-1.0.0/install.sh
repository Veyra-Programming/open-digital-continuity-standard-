#!/bin/sh
echo "Installing Haven Language v1.0.0 (ODCS Standard)..."
mkdir -p /usr/local/bin /usr/local/lib/haven
cp -r lib/haven/* /usr/local/lib/haven/
cp bin/haven /usr/local/bin/haven
chmod +x /usr/local/bin/haven
echo "Installation complete! Run 'haven --help' to begin."
