# Haven Language CLI Runner
import sys
import os
haven_lib = os.path.dirname(os.path.abspath(__file__))
if haven_lib not in sys.path:
    sys.path.insert(0, haven_lib)
from haven.cli.main import main
if __name__ == '__main__':
    sys.exit(main())
